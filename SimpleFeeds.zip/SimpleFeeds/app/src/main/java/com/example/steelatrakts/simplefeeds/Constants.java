package com.example.steelatrakts.simplefeeds;

public class Constants {

	public static final String TAG = "RssApp";

}
